import DriversOfPotential from './DriversOfPotential';

export default DriversOfPotential;
