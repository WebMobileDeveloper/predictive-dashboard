import Effectiveness from './Effectiveness';

export default Effectiveness;
