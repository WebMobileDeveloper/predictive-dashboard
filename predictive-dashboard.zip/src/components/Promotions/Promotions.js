import React from 'react';
import Grid from 'material-ui/Grid';

import { SegmentHeader } from '../shared/index';
import HeadPageSVG from './HeadPageSVG';
import AlertBoxSVG from './AlertBoxSVG';
import TableContainer from './BarStack/TableContainer';
import PageSVG from './PageSVG';

const Promotions = () => (
  <PageSVG/>
  // <Grid container
  //       spacing={0}
  //       direction={'column'}>

  //   <HeadPageSVG/>

  //   <AlertBoxSVG/>

  //   <SegmentHeader title={'Promotional Plan'}/>
  //   <Grid item xs={12}>
  //     <TableContainer dataCategory="promotions"/>
  //   </Grid>

  // </Grid>
);

export default Promotions;
