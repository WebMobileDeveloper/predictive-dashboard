import Opportunity from './Opportunity';

export default Opportunity;
