import FullPotential from './FullPotential';

export default FullPotential;
