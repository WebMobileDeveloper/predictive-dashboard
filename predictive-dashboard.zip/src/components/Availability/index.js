import Availability from './Availability';

export default Availability;
