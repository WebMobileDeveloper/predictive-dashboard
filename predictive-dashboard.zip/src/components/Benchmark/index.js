import Benchmark from './Benchmark';

export default Benchmark;
