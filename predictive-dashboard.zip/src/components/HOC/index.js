import getData from './getData';
import getFullPotentialData from './getFullPotentialData';
import getAnalysisData from './getAnalysisData';

export { getData, getFullPotentialData, getAnalysisData };
