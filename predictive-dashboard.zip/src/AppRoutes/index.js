import AppRoutes from './AppRoutes';

export default AppRoutes;
