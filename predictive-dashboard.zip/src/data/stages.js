export const STAGES = [
  { key: 'nextWeek', value: 'Next Week' },
  { key: 'nextMonth', value: 'Next Month' },
  { key: 'nextQuarter', value: 'Next Quarter' },
  { key: '2018', value: '2018' },
];
