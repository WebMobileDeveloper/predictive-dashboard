export default {
  red: '#DD0000',
  green: '#00BA00',
  blue: '#2296F4',
  orange: '#F99F41',
  grey: '#6E797C',
  darkgrey: '#666',
};
